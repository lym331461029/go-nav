//
// Created by 李永明 on 2022/5/24.
//

#include "navQueryFilter.h"

#ifdef DT_VIRTUAL_QUERYFILTER
bool offMeshConnQueryFilter::passFilter(const dtPolyRef ref,
	const dtMeshTile* tile,
	const dtPoly* poly) const
{
	if (poly->getType() == DT_POLYTYPE_OFFMESH_CONNECTION && m_pSample != NULL)
	{
		int index = poly - tile->polys - tile->header->offMeshBase;
		uint32_t offMeshConnId = tile->offMeshCons[index].userId; //查当前offMeshConnection的id
		if (offMeshConnId > 0)
		{
			int64_t allianceId = m_pSample->getOffMeshConnOccupied(offMeshConnId); //查看offMeshConnection的被哪个联盟占领
			if (allianceId > 0 && allianceId != m_pSample->getAllianceId())
			{
				return false;
			}
		}
	}
	return dtQueryFilter::passFilter(ref, tile, poly);
}

bool unusebleQueryFilter::passFilter(const dtPolyRef ref,
	const dtMeshTile* tile,
	const dtPoly* poly) const
{
	//printf("polyarea : %d, polyflag: %d\n", poly->getArea(), poly->flags);
	if (poly->getArea() == SAMPLE_POLYAREA_OBSTACLE)
	{
		return true;
	}
	if (poly->flags & SAMPLE_POLYFLAGS_DISABLED)
	{
		return true;
	}
	return false;
}
#else
inline bool offMeshConnQueryFilter::passFilter(const dtPolyRef ref,
									  const dtMeshTile* tile,
									  const dtPoly* poly) const
{
	return dtQueryFilter::passFilter(ref,tile,poly);
}

bool unusebleQueryFilter::passFilter(const dtPolyRef ref,
	const dtMeshTile* tile,
	const dtPoly* poly) const
{
	if (poly->getArea() == SAMPLE_POLYAREA_OBSTACLE)
	{
		return true;
	}
	if (poly->flags & SAMPLE_POLYFLAGS_DISABLED)
	{
		return true;
	}
	return false;
}
#endif
