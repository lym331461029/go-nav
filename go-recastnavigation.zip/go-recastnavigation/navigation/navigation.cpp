#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>

#include "DetourCommon.h"
#include "DetourNavMeshQuery.h"
#include "DetourStatus.h"
#include "InputGeom.h"
#include "Sample_TempObstacles.h"
#include "navQueryFilter.h"

#include <map>
#include <vector>

#ifndef NavigationAPI
#ifdef _WIN32
#define NavigationAPI __declspec(dllexport)
#else
#define NavigationAPI
#endif
#endif

#define SAFE_DEL_PTR(p)                                                        \
  if (p)                                                                       \
    delete p;                                                                  \
  p = NULL

extern "C" {

typedef struct {
  float x, y, z;
} navigation_position_t;

typedef struct {
  float tileSize;
  float cellSize;
  float cellHeight;
  float agentRadius;
} nav_mesh_param_t;

typedef struct navigation_sdk {
  Sample *sample;
  std::map<int, std::vector<navigation_position_t>> resultCache;
  int cacheSeq;
  std::mutex mutex;
} * navigation_sdk_t;

NavigationAPI navigation_sdk_t navigation_sdk_create(nav_mesh_param_t param) {
  navigation_sdk_t sdk = new navigation_sdk();

  if (param.tileSize < 48) {
    param.tileSize = 48;
  }
  sdk->sample = new Sample_TempObstacles(param.tileSize);

  if (param.cellSize < 0.1f) {
    param.cellSize = 0.1f;
  }

  if (param.cellHeight < 0.2f) {
    param.cellHeight = 0.2f;
  }

  if (param.agentRadius < 0.1f) {
    param.agentRadius = 0.1f;
  }

  sdk->sample->setParams(param.cellSize, param.cellHeight, param.agentRadius);

  sdk->cacheSeq = 1000;
  srand(time(NULL));
  return sdk;
}

NavigationAPI int LoadMap(char *path, navigation_sdk_t sdk) {
  if (!sdk)
    return -1;
  std::lock_guard<std::mutex> lockGuard(sdk->mutex);
  Sample *sample = sdk->sample;

  InputGeom *geom = sample->getInputGeom();
  if (geom != NULL) {
    SAFE_DEL_PTR(geom);
  }

  BuildContext *ctx = sample->getContext();
  if (ctx != NULL) {
    SAFE_DEL_PTR(ctx);
  }

  geom = new InputGeom();
  ctx = new BuildContext();

  if (!geom || !ctx)
    return -1;

  ctx->resetLog();
  if (!geom->load(ctx, path)) {
    SAFE_DEL_PTR(geom);
    SAFE_DEL_PTR(ctx);
    return -1;
  }

  sample->setContext(ctx);
  sample->handleMeshChanged(geom);
  sample->handleSettings();
  sample->handleBuild();
  return 1;
}

NavigationAPI void UnloadMap(navigation_sdk_t sdk) {
  if (!sdk)
    return;
  std::lock_guard<std::mutex> lockGuard(sdk->mutex);

  Sample *sample = sdk->sample;
  InputGeom *geom = sample->getInputGeom();
  if (geom != NULL) {
    SAFE_DEL_PTR(geom);
  }

  BuildContext *ctx = sample->getContext();
  if (ctx != NULL) {
    SAFE_DEL_PTR(ctx);
  }

  SAFE_DEL_PTR(sample);
}

NavigationAPI int FindPath(navigation_position_t start,
                           navigation_position_t end, navigation_sdk_t sdk) {
  if (!sdk)
    return -1;
  // std::lock_guard<std::mutex> lockGuard(sdk->mutex);
  Sample *sample = sdk->sample;
  float startPos[3];
  startPos[0] = start.x;
  startPos[1] = start.y;
  startPos[2] = start.z;

  float endPos[3];
  endPos[0] = end.x;
  endPos[1] = end.y;
  endPos[2] = end.z;

  float ingore = 0.0f;

  sample->handleClick(&ingore, startPos, true);
  sample->handleClick(&ingore, endPos, false);
  return sample->getResultNum();
}

NavigationAPI int GetValue(int index, navigation_sdk_t sdk,
                           navigation_position_t *pos) {
  if (!sdk || !pos)
    return -1;

  Sample *sample = sdk->sample;
  float out[3] = {0};
  bool ret = sample->getResultByIndex(index, out);
  if (ret == false)
    return -1;
  pos->x = out[0];
  pos->y = out[1];
  pos->z = out[2];
  return 1;
}

NavigationAPI int FindPath2(navigation_position_t start,
                            navigation_position_t end, navigation_sdk_t sdk,
                            navigation_position_t **ret, int *retLen,
                            int64_t allianceId, int *partial, int *outOfNodes) {
  if (!sdk)
    return -1;

  printf("%s\n", "FindPath2");

  Sample *sample = sdk->sample;
  Sample_TempObstacles *tempObstacleSample =
      dynamic_cast<Sample_TempObstacles *>(sample);
  tempObstacleSample->setAllianceId(allianceId);
  float startPos[3];
  startPos[0] = start.x;
  startPos[1] = start.y;
  startPos[2] = start.z;

  float endPos[3];
  endPos[0] = end.x;
  endPos[1] = end.y;
  endPos[2] = end.z;

  float ingore = 0.0f;

  int resultNum = 0;
  {
    std::lock_guard<std::mutex> lockGuard(sdk->mutex);
    tempObstacleSample->handleClick(&ingore, startPos, true);
    tempObstacleSample->handleClick(&ingore, endPos, false);
    resultNum = tempObstacleSample->getResultNum();

    if (resultNum > 0) {
      int cacheNum = /*rand()  * 10000 +*/ sdk->cacheSeq++;
      navigation_position_t pos;

      sdk->resultCache[cacheNum].resize(resultNum);
      navigation_position_t *dataPtr = sdk->resultCache[cacheNum].data();

      tempObstacleSample->getAllResult((float *)dataPtr);

      // float out[3] = {0};
      // for (int index = 0; index < resultNum; index++) {
      //   bool ret = tempObstacleSample->getResultByIndex(index, out);
      //   if (ret) {
      //     pos.x = out[0];
      //     pos.y = out[1];
      //     pos.z = out[2];
      //     sdk->resultCache[cacheNum].push_back(pos);
      //   }
      // }
      resultNum = cacheNum;
      *ret = sdk->resultCache[cacheNum].data();
      *retLen = sdk->resultCache[cacheNum].size();

      dtStatus st = tempObstacleSample->getFindPathStatus();
      if (outOfNodes != NULL && dtStatusDetail(st, DT_OUT_OF_NODES)) {
        *outOfNodes = 1;
      }

      if (partial != NULL && dtStatusDetail(st, DT_PARTIAL_RESULT)) {
        *partial = 1;
      }
    }
  }
  tempObstacleSample->setAllianceId(0);
  tempObstacleSample->resetFindPathStatus();
  return resultNum;
}

NavigationAPI int FreePathCache(navigation_sdk_t sdk, int cacheSeq) {
  if (!sdk)
    return -1;
  std::lock_guard<std::mutex> lockGuard(sdk->mutex);

  sdk->resultCache.erase(cacheSeq);
  // printf("%s\n", "FreePathCache");
  return 0;
}

// typedef unsigned int uint;
NavigationAPI int AddCylinderObstacle(navigation_sdk_t sdk,
                                      navigation_position_t pos,
                                      const float radius, const float height,
                                      uint32_t *result) {
  if (!sdk)
    return -1;
  std::lock_guard<std::mutex> lockGuard(sdk->mutex);

  printf("%s\n", "AddObstacle");

  Sample *sample = sdk->sample;
  Sample_TempObstacles *tempObstacleSample =
      dynamic_cast<Sample_TempObstacles *>(sample);

  // tempObstacleSample->saveNavMesh("./mesh_add_before.bin",
  // tempObstacleSample->getNavMesh());

  float inputPos[3];
  inputPos[0] = pos.x;
  inputPos[1] = pos.y;
  inputPos[2] = pos.z;

  int code =
      tempObstacleSample->addTempObstacle(inputPos, radius, height, result);
  if (code != 0) {
    return -1;
  }
  tempObstacleSample->handleUpdate(inputPos[0]);

  // tempObstacleSample->saveNavMesh("./mesh_add_after.bin",
  // tempObstacleSample->getNavMesh());

  return 0;
}

NavigationAPI int AddBoxObstacle(navigation_sdk_t sdk,
                                 navigation_position_t bMinPos,
                                 navigation_position_t bMaxPos,
                                 uint32_t *result) {
  if (!sdk)
    return -1;
  std::lock_guard<std::mutex> lockGuard(sdk->mutex);

  printf("%s\n", "AddBoxObstacle");

  Sample *sample = sdk->sample;
  Sample_TempObstacles *tempObstacleSample =
      dynamic_cast<Sample_TempObstacles *>(sample);

  float inputBMin[3], inputBMax[3];
  inputBMin[0] = bMinPos.x;
  inputBMin[1] = bMinPos.y;
  inputBMin[2] = bMinPos.z;

  inputBMax[0] = bMaxPos.x;
  inputBMax[1] = bMaxPos.y;
  inputBMax[2] = bMaxPos.z;

  int code =
      tempObstacleSample->addBoxTempObstacle(inputBMin, inputBMax, result);
  if (code != 0) {
    return -1;
  }
  tempObstacleSample->handleUpdate(inputBMin[0]);
  return 0;
}

NavigationAPI int RemoveObstacle(navigation_sdk_t sdk, uint32_t refNo) {
  if (!sdk)
    return -1;
  std::lock_guard<std::mutex> lockGuard(sdk->mutex);

  printf("%s\n", "RemoveObstacle");
  Sample *sample = sdk->sample;
  Sample_TempObstacles *tempObstacleSample =
      dynamic_cast<Sample_TempObstacles *>(sample);

  if (tempObstacleSample->removeTempObstacleByRef(refNo) == 0) {
    float x = 0;
    tempObstacleSample->handleUpdate(x);
    return 0;
  }

  return -1;
}

NavigationAPI int FindRandomPointAroundCircle(
    navigation_sdk_t sdk, navigation_position_t centerPos,
    const float maxRadius, navigation_position_t *randomPos) {
  if (!sdk)
    return -1;
  std::lock_guard<std::mutex> lockGuard(sdk->mutex);

  Sample *sample = sdk->sample;
  Sample_TempObstacles *tempObstacleSample =
      dynamic_cast<Sample_TempObstacles *>(sample);

  float center[3];
  center[0] = centerPos.x;
  center[1] = centerPos.y;
  center[2] = centerPos.z;

  dtPolyRef ref;
  float retPos[3];

  unsigned int status = tempObstacleSample->findRandomPointAroundCircle(
      center, maxRadius, &ref, retPos);
  if (status != DT_SUCCESS) {
    return -1;
  }

  randomPos->x = retPos[0];
  randomPos->y = retPos[1];
  randomPos->z = retPos[2];
  return 0;
}

NavigationAPI int AddOffMeshConnection(navigation_sdk_t sdk,
                                       navigation_position_t startPos,
                                       navigation_position_t endPos,
                                       uint32_t offMeshConnId) {
  if (!sdk)
    return -1;
  Sample *sample = sdk->sample;

  float start[3];
  start[0] = startPos.x;
  start[1] = startPos.y;
  start[2] = startPos.z;

  float end[3];
  end[0] = endPos.x;
  end[1] = endPos.y;
  end[2] = endPos.z;

  InputGeom *geom = sample->getInputGeom();
  if (geom == NULL) {
    return -1;
  }

  float radius = 0.6;
  const unsigned char area = SAMPLE_POLYAREA_JUMP;
  const unsigned short flags = SAMPLE_POLYFLAGS_JUMP;

  std::lock_guard<std::mutex> lockGuard(sdk->mutex);
  geom->addOffMeshConnection(start, end, radius, 1, area, flags, offMeshConnId);

  if (sample->handleBuild()) {
    return 0;
  }
  return -1;
}

NavigationAPI int DelOffMeshConnection(navigation_sdk_t sdk,
                                       uint32_t offMeshConnId) {
  if (!sdk)
    return -1;
  Sample *sample = sdk->sample;

  InputGeom *geom = sample->getInputGeom();
  if (geom == NULL) {
    return -1;
  }
  std::lock_guard<std::mutex> lockGuard(sdk->mutex);
  geom->deleteOffMeshConnById(offMeshConnId);
  if (sample->handleBuild()) {
    sample->delOffMeshConn(offMeshConnId);
    return 0;
  }
  return -1;
}

NavigationAPI void SetOffMeshConnOccupied(navigation_sdk_t sdk,
                                          uint32_t offMeshConnId,
                                          int64_t allianceId) {
  if (!sdk)
    return;
  Sample *sample = sdk->sample;

  sample->setOffMeshConnOccupied(offMeshConnId, allianceId);
}

NavigationAPI int CheckAreaUsable(navigation_sdk_t sdk,
                                  navigation_position_t centerPos, float halfX,
                                  float halfY, float halfZ) {
  if (!sdk)
    return -1;
  Sample *sample = sdk->sample;

  float center[3];
  center[0] = centerPos.x;
  center[1] = centerPos.y;
  center[2] = centerPos.z;

  float half[3];
  half[0] = halfX;
  half[1] = halfY;
  half[2] = halfZ;

  unusebleQueryFilter filter;
  filter.setIncludeFlags(SAMPLE_POLYFLAGS_ALL ^ SAMPLE_POLYFLAGS_DISABLED);
  filter.setExcludeFlags(SAMPLE_POLYFLAGS_DISABLED);
  dtPolyRef ref;
  int count = -1;

  std::lock_guard<std::mutex> lockGuard(sdk->mutex);
  sample->getNavMeshQuery()->queryPolygons(center, half, &filter, &ref, &count,
                                           1);

  return count;
}

NavigationAPI int CheckBoxAreaUsable(navigation_sdk_t sdk,
                                     navigation_position_t centerPos,
                                     float halfX, float halfY, float halfZ) {
  if (!sdk)
    return -1;
  Sample *sample = sdk->sample;

  float center[3];
  center[0] = centerPos.x;
  center[1] = centerPos.y;
  center[2] = centerPos.z;
  float halfExt[3] = {2, 4, 2};

  float radius = dtMathSqrtf(dtSqr(halfX) + dtSqr(halfZ));

  dtPolyRef centerRef = 0;
  float nearestPt[3];
  dtQueryFilter filter;
  filter.setIncludeFlags(SAMPLE_POLYFLAGS_ALL ^ SAMPLE_POLYFLAGS_DISABLED);
  filter.setExcludeFlags(SAMPLE_POLYFLAGS_DISABLED);
  auto query = sample->getNavMeshQuery();

  std::lock_guard<std::mutex> lockGuard(sdk->mutex);
  query->findNearestPoly(center, halfExt, &filter, &centerRef, nearestPt);

  if (centerRef > 0) {
    float hitDist;
    float hitPos[3];
    float hitNorm[3];
    query->findDistanceToWall(centerRef, nearestPt, radius, &filter, &hitDist,
                              hitPos, hitNorm);
    if (hitDist > radius) {
      return 0;
    }

    //撞墙相交点在方体平面投影区域外
    if (dtAbs(hitPos[0] - nearestPt[0]) > halfX ||
        dtAbs(hitPos[2] - nearestPt[2]) > halfZ) {
      return 0;
    }
  }
  return -1;
}

NavigationAPI int CheckCircleAreaUsable(navigation_sdk_t sdk,
                                        navigation_position_t centerPos,
                                        float radius) {
  if (!sdk)
    return -1;
  Sample *sample = sdk->sample;

  float center[3];
  center[0] = centerPos.x;
  center[1] = centerPos.y;
  center[2] = centerPos.z;

  float halfExt[3] = {2, 4, 2};

  dtPolyRef centerRef = 0;
  float nearestPt[3];
  dtQueryFilter filter;
  filter.setIncludeFlags(SAMPLE_POLYFLAGS_ALL ^ SAMPLE_POLYFLAGS_DISABLED);
  filter.setExcludeFlags(SAMPLE_POLYFLAGS_DISABLED);
  auto query = sample->getNavMeshQuery();

  std::lock_guard<std::mutex> lockGuard(sdk->mutex);
  query->findNearestPoly(center, halfExt, &filter, &centerRef, nearestPt);
  if (centerRef > 0) {
    float hitDist;
    float hitPos[3];
    float hitNorm[3];
    query->findDistanceToWall(centerRef, nearestPt, radius + 5, &filter,
                              &hitDist, hitPos, hitNorm);
    if (hitDist > radius) {
      return 0;
    }
  }
  return -1;
}
}
