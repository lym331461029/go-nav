//
// Created by 李永明 on 2022/5/24.
//

#ifndef RECASTNAVIGATION_OFFMESHCONNQUERYFILTER_H
#define RECASTNAVIGATION_OFFMESHCONNQUERYFILTER_H

#include "DetourNavMeshQuery.h"
#include "Sample.h"

class offMeshConnQueryFilter : public dtQueryFilter
{
public:
	inline offMeshConnQueryFilter()
	{
	}
	inline void init(Sample* sample)
	{
		m_pSample = sample;
	}
#ifdef DT_VIRTUAL_QUERYFILTER
	virtual ~offMeshConnQueryFilter()
	{
	}
#endif

#ifdef DT_VIRTUAL_QUERYFILTER
	virtual bool passFilter(const dtPolyRef ref,
		const dtMeshTile* tile,
		const dtPoly* poly) const;
#else
	bool passFilter(const dtPolyRef ref,
					const dtMeshTile* tile,
					const dtPoly* poly) const;
#endif

private:
	Sample* m_pSample;
};

class unusebleQueryFilter : public dtQueryFilter
{
public:
	inline unusebleQueryFilter()
	{
	}
#ifdef DT_VIRTUAL_QUERYFILTER
	virtual ~unusebleQueryFilter()
	{
	}
#endif

#ifdef DT_VIRTUAL_QUERYFILTER
	virtual bool passFilter(const dtPolyRef ref,
		const dtMeshTile* tile,
		const dtPoly* poly) const;
#else
	bool passFilter(const dtPolyRef ref,
					const dtMeshTile* tile,
					const dtPoly* poly) const;
#endif
};

#endif //RECASTNAVIGATION_OFFMESHCONNQUERYFILTER_H
