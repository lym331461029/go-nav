/* Define to the library version */
#define RECASTNAV_VERSION "1.5.1"
#define RECASTNAV_VERSION_NUM 1,5,1,0
