DIR=$(cd $(dirname $0);  pwd)
cd $DIR


# 如果镜像不存在先打包镜像
if [[ "$(docker images -q go-recastnavigation-build-centos7 2> /dev/null)" == "" ]]; then
	 docker build -t go-recastnavigation-build-centos7:v1 .
fi



WORK_SPACE_DIR="${DIR}/workspace"
SRC_DIR="${WORK_SPACE_DIR}/src"
OUT_DIR="${WORK_SPACE_DIR}/out"
if [ -d $SRC_DIR ];then
	rm -rf $SRC_DIR
fi
mkdir -p $SRC_DIR
cp -rf ../CMakeLists.txt $SRC_DIR
cp -rf ../DetourCrowd $SRC_DIR
cp -rf ../RecastDemo $SRC_DIR
cp -rf ../DetourTileCache $SRC_DIR
cp -rf ../navigation $SRC_DIR
cp -rf ../Detour $SRC_DIR
cp -rf ../Recast $SRC_DIR
cp -rf ../version.h.in $SRC_DIR
cp -rf ../DebugUtils $SRC_DIR



if [ -d $OUT_DIR ];then
	rm -rf $OUT_DIR
fi
mkdir -p $OUT_DIR





docker run  --rm -v $WORK_SPACE_DIR:/data/navigation "go-recastnavigation-build-centos7:v1"  
# docker start go-recastnavigation-build-centos7:v1  